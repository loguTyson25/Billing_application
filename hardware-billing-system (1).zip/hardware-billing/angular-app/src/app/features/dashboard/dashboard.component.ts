// src/app/features/dashboard/dashboard.component.ts
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/services/api.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-dashboard',
  template: `
<div class="dashboard">

  <!-- KPI Grid -->
  <div class="kpi-grid">
    <div class="kpi-card" *ngFor="let k of kpis" [class]="'kpi-' + k.type">
      <div class="kpi-icon">{{ k.icon }}</div>
      <div class="kpi-body">
        <div class="kpi-label">{{ k.label }}</div>
        <div class="kpi-value">{{ k.value }}</div>
      </div>
    </div>
  </div>

  <!-- Two column layout -->
  <div class="dash-grid">

    <!-- Recent Invoices -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Recent Invoices</h3>
        <a routerLink="/invoices" class="view-link">View all →</a>
      </div>
      <div *ngIf="loading" class="loading-state">
        <div class="spinner"></div> Loading...
      </div>
      <div class="table-wrap" *ngIf="!loading">
        <table class="dt">
          <thead>
            <tr>
              <th>Invoice #</th>
              <th>Customer</th>
              <th>Amount</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let inv of data?.recentInvoices">
              <td><span class="mono">{{ inv.invoiceNo }}</span></td>
              <td>{{ inv.customerName }}</td>
              <td class="fw">{{ cur }}{{ inv.total | number:'1.0-0' }}</td>
              <td>
                <span class="badge" [ngClass]="'b-' + inv.paymentStatus">
                  {{ inv.paymentStatus }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
        <div *ngIf="!data?.recentInvoices?.length" class="empty-row">No invoices yet</div>
      </div>
    </div>

    <!-- Low Stock -->
    <div class="card alert-card">
      <div class="card-header">
        <h3 class="card-title">⚠ Low Stock Alerts</h3>
        <a routerLink="/products" class="view-link">Manage →</a>
      </div>
      <div *ngIf="!data?.lowStockItems?.length" class="all-clear">
        <span class="clear-icon">✅</span>
        All products sufficiently stocked
      </div>
      <div class="stock-list" *ngIf="data?.lowStockItems?.length">
        <div class="stock-item" *ngFor="let p of data?.lowStockItems">
          <div class="si-info">
            <div class="si-name">{{ p.name }}</div>
            <div class="si-sku">{{ p.sku }}</div>
          </div>
          <span class="stock-pill" [class.out-pill]="p.stock == 0">
            {{ p.stock == 0 ? 'OUT OF STOCK' : p.stock + ' ' + p.unit }}
          </span>
        </div>
      </div>
    </div>
  </div>
</div>
  `,
  styles: [`
    .dashboard { display: flex; flex-direction: column; gap: 20px; }

    /* KPI Grid */
    .kpi-grid {
      display: grid;
      grid-template-columns: repeat(6, 1fr);
      gap: 12px;
    }
    .kpi-card {
      background: var(--white);
      border-radius: var(--radius-lg);
      padding: 16px;
      display: flex;
      gap: 12px;
      align-items: center;
      border: 1px solid var(--gray-border);
      border-top: 3px solid var(--gray-border);
      box-shadow: var(--shadow-sm);
      transition: transform 0.15s, box-shadow 0.15s;
    }
    .kpi-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); }
    .kpi-gold  { border-top-color: var(--gold); }
    .kpi-navy  { border-top-color: var(--navy); }
    .kpi-green { border-top-color: var(--success); }
    .kpi-red   { border-top-color: var(--danger); }
    .kpi-blue  { border-top-color: #3b82f6; }
    .kpi-amber { border-top-color: var(--warning); }

    .kpi-icon { font-size: 26px; }
    .kpi-label {
      font-size: 10px;
      color: var(--text-muted);
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .kpi-value {
      font-size: 18px;
      font-weight: 800;
      color: var(--navy);
      margin-top: 3px;
      letter-spacing: -0.3px;
    }

    /* Dash grid */
    .dash-grid {
      display: grid;
      grid-template-columns: 1fr 380px;
      gap: 16px;
    }

    /* Cards */
    .card {
      background: var(--white);
      border-radius: var(--radius-lg);
      border: 1px solid var(--gray-border);
      overflow: hidden;
      box-shadow: var(--shadow-sm);
    }
    .alert-card { border-top: 3px solid var(--danger); }

    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 20px;
      border-bottom: 1px solid var(--gray-border);
    }
    .card-title {
      font-size: 14px;
      font-weight: 700;
      color: var(--navy);
      margin: 0;
    }
    .view-link {
      font-size: 12px;
      color: var(--gold-dark);
      font-weight: 600;
      text-decoration: none;
    }
    .view-link:hover { color: var(--gold); }

    /* Table */
    .table-wrap { overflow-x: auto; }
    .dt { width: 100%; border-collapse: collapse; font-size: 13px; }
    .dt th {
      padding: 10px 16px;
      text-align: left;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      color: var(--text-muted);
      background: var(--gray-soft);
      border-bottom: 1px solid var(--gray-border);
      white-space: nowrap;
    }
    .dt td { padding: 11px 16px; border-bottom: 1px solid #f8fafc; color: var(--text-mid); }
    .dt tr:last-child td { border-bottom: none; }
    .dt tr:hover td { background: var(--gold-soft); }
    .mono { font-family: monospace; color: var(--navy-mid); font-weight: 700; font-size: 12px; }
    .fw { font-weight: 700; }
    .empty-row { text-align: center; padding: 32px; color: var(--text-muted); font-size: 13px; }

    /* Badges */
    .badge { font-size: 10px; padding: 3px 8px; border-radius: 20px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.3px; }
    .b-paid    { background: #dcfce7; color: #166534; }
    .b-partial { background: #fef9c3; color: #854d0e; }
    .b-unpaid  { background: #fee2e2; color: #991b1b; }

    /* Stock */
    .stock-list { padding: 12px 16px; display: flex; flex-direction: column; gap: 8px; }
    .stock-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 14px;
      background: #fff7f7;
      border-radius: var(--radius-md);
      border: 1px solid #fee2e2;
    }
    .si-name { font-size: 13px; font-weight: 600; color: var(--navy); }
    .si-sku  { font-size: 10px; color: var(--text-muted); margin-top: 2px; }
    .stock-pill {
      font-size: 10px; font-weight: 700;
      padding: 4px 10px; border-radius: 20px;
      background: #fef3c7; color: #92400e;
      white-space: nowrap;
    }
    .out-pill { background: #fee2e2; color: #991b1b; }

    .all-clear {
      display: flex; flex-direction: column; align-items: center;
      gap: 8px; padding: 40px; color: var(--success);
      font-size: 13px; font-weight: 600;
    }
    .clear-icon { font-size: 28px; }

    /* Loading */
    .loading-state {
      display: flex; align-items: center; gap: 10px;
      padding: 40px; color: var(--text-muted); font-size: 13px;
    }
    .spinner {
      width: 18px; height: 18px;
      border: 2px solid var(--gray-border);
      border-top-color: var(--gold);
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin { to { transform: rotate(360deg); } }

    /* Responsive */
    @media (max-width: 1280px) {
      .kpi-grid { grid-template-columns: repeat(3, 1fr); }
    }
    @media (max-width: 900px) {
      .kpi-grid { grid-template-columns: repeat(2, 1fr); }
      .dash-grid { grid-template-columns: 1fr; }
    }
    @media (max-width: 480px) {
      .kpi-grid { grid-template-columns: repeat(2, 1fr); gap: 8px; }
      .kpi-card { padding: 12px; gap: 8px; }
      .kpi-icon { font-size: 20px; }
      .kpi-value { font-size: 15px; }
    }
  `]
})
export class DashboardComponent implements OnInit {
  cur = environment.currency;
  data: any = null;
  loading = true;
  kpis: any[] = [];

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.api.getDashboard().subscribe({
      next: d => {
        this.data = d;
        this.loading = false;
        this.kpis = [
          { icon: '💰', label: "Today's Sales",  value: `${this.cur}${Number(d.todaySales).toLocaleString('en-IN')}`,  type: 'gold' },
          { icon: '📅', label: 'Month Sales',    value: `${this.cur}${Number(d.monthSales).toLocaleString('en-IN')}`,  type: 'navy' },
          { icon: '⏳', label: 'Outstanding',    value: `${this.cur}${Number(d.outstanding).toLocaleString('en-IN')}`, type: 'red' },
          { icon: '👥', label: 'Customers',      value: d.totalCustomers,  type: 'blue' },
          { icon: '📦', label: 'Products',       value: d.totalProducts,   type: 'green' },
          { icon: '⚠️', label: 'Low Stock',      value: d.lowStockCount,   type: 'amber' },
        ];
      },
      error: () => { this.loading = false; }
    });
  }
}
