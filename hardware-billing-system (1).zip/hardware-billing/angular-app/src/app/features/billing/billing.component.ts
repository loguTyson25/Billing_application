// src/app/features/billing/billing.component.ts
import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/services/api.service';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-billing',
  template: `
<div class="billing-screen">

  <!-- LEFT COLUMN -->
  <div class="billing-left">

    <!-- Customer -->
    <div class="panel">
      <div class="panel-header"><span class="ph-icon">👤</span> Customer</div>
      <div class="panel-body">
        <div class="input-row">
          <select [(ngModel)]="selectedCustomerId" (change)="onCustomerChange()" class="fc">
            <option value="">— Walk-in Customer —</option>
            <option *ngFor="let c of customers" [value]="c.id">{{ c.name }} ({{ c.phone }})</option>
          </select>
          <button class="icon-btn" (click)="showNewCustomer = !showNewCustomer" title="Add customer">+</button>
        </div>
        <div *ngIf="selectedCustomer" class="cust-info">
          <span class="ci-item">📞 {{ selectedCustomer.phone }}</span>
          <span class="ci-due" *ngIf="selectedCustomer.outstanding > 0">
            Due: {{ cur }}{{ selectedCustomer.outstanding | number:'1.0-0' }}
          </span>
        </div>
        <div *ngIf="showNewCustomer" class="quick-add">
          <input [(ngModel)]="newCust.name"    placeholder="Name *"    class="fc" />
          <input [(ngModel)]="newCust.phone"   placeholder="Phone"     class="fc" />
          <input [(ngModel)]="newCust.address" placeholder="Address"   class="fc" />
          <button class="btn-save-cust" (click)="addCustomer()">✔ Save Customer</button>
        </div>
      </div>
    </div>

    <!-- Product search -->
    <div class="panel">
      <div class="panel-header"><span class="ph-icon">📦</span> Add Products</div>
      <div class="panel-body">
        <input
          [(ngModel)]="productSearch"
          (input)="filterProducts()"
          placeholder="🔍 Search by name, SKU or scan barcode..."
          class="fc search-fc"
        />
        <div class="prod-dropdown" *ngIf="filteredProducts.length && productSearch">
          <div class="prod-opt" *ngFor="let p of filteredProducts.slice(0,8)" (click)="addToCart(p)">
            <div>
              <div class="po-name">{{ p.name }}</div>
              <div class="po-meta">{{ p.sku }} &bull; {{ p.unit }} &bull; Stock: {{ p.stock }}</div>
            </div>
            <div class="po-price">{{ cur }}{{ p.price }}</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Cart -->
    <div class="panel cart-panel">
      <div class="panel-header">
        <span class="ph-icon">🛒</span> Bill Items
        <span class="item-count" *ngIf="cartItems.length">{{ cartItems.length }} items</span>
      </div>
      <div *ngIf="!cartItems.length" class="empty-cart">
        <div class="ec-icon">🛒</div>
        <div>No items added. Search products above.</div>
      </div>
      <div class="cart-wrap" *ngIf="cartItems.length">
        <table class="cart-tbl">
          <thead>
            <tr>
              <th>Item</th>
              <th class="tc">Qty</th>
              <th class="tc">Price</th>
              <th class="tc">Disc%</th>
              <th class="tc">Tax</th>
              <th class="tr">Total</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let item of cartItems; let i = index">
              <td>
                <div class="ci-name">{{ item.productName }}</div>
                <div class="ci-sku">{{ item.sku }}</div>
              </td>
              <td class="tc">
                <input type="number" [(ngModel)]="item.qty" min="1" class="num-input"
                       (ngModelChange)="recalcItem(item)" />
              </td>
              <td class="tc">
                <input type="number" [(ngModel)]="item.price" class="num-input wide"
                       (ngModelChange)="recalcItem(item)" />
              </td>
              <td class="tc">
                <input type="number" [(ngModel)]="item.discount" min="0" max="100" class="num-input"
                       (ngModelChange)="recalcItem(item)" />
              </td>
              <td class="tc muted">{{ item.taxRate }}%</td>
              <td class="tr fw">{{ cur }}{{ item.lineTotal | number:'1.2-2' }}</td>
              <td>
                <button class="rm-btn" (click)="removeItem(i)" title="Remove">✕</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- RIGHT COLUMN: Summary -->
  <div class="billing-right">
    <div class="summary-card">
      <div class="sc-header">
        <span class="sc-logo">◆</span> Payment Summary
      </div>

      <div class="sum-rows">
        <div class="sum-row"><span>Subtotal</span><span>{{ cur }}{{ subtotal | number:'1.2-2' }}</span></div>
        <div class="sum-row discount-row">
          <span>Discount ({{ billDiscount }}%)</span>
          <span class="text-red">−{{ cur }}{{ discountAmount | number:'1.2-2' }}</span>
        </div>
        <div class="sum-row"><span>GST / Tax</span><span>{{ cur }}{{ taxTotal | number:'1.2-2' }}</span></div>
        <div class="sum-row total-row">
          <span>Grand Total</span>
          <span>{{ cur }}{{ grandTotal | number:'1.2-2' }}</span>
        </div>
      </div>

      <div class="sc-body">
        <!-- Discount -->
        <div class="field-block">
          <label>Bill Discount (%)</label>
          <input type="number" [(ngModel)]="billDiscount" min="0" max="100" class="fc"
                 (ngModelChange)="recalcTotals()" />
        </div>

        <!-- Payment mode -->
        <div class="field-block">
          <label>Payment Mode</label>
          <div class="mode-grid">
            <button *ngFor="let m of paymentModes"
                    [class.active]="paymentMode === m.value"
                    (click)="paymentMode = m.value"
                    class="mode-btn">
              <span>{{ m.icon }}</span>
              <span>{{ m.label }}</span>
            </button>
          </div>
        </div>

        <!-- Amount paid -->
        <div class="field-block">
          <label>Amount Paid ({{ cur }})</label>
          <input type="number" [(ngModel)]="amountPaid" class="fc amount-input" />
        </div>

        <!-- Balance -->
        <div class="balance-row" [class.has-due]="grandTotal - amountPaid > 0">
          <span>Balance Due</span>
          <span class="bal-val">{{ cur }}{{ (grandTotal - amountPaid) | number:'1.2-2' }}</span>
        </div>

        <!-- Date -->
        <div class="field-block">
          <label>Invoice Date</label>
          <input type="date" [(ngModel)]="invoiceDate" class="fc" />
        </div>

        <!-- Notes -->
        <div class="field-block">
          <label>Notes</label>
          <textarea [(ngModel)]="notes" class="fc" rows="2" placeholder="Optional..."></textarea>
        </div>

        <!-- Actions -->
        <div class="action-row">
          <button class="btn-save" (click)="saveBill()" [disabled]="!cartItems.length || saving">
            {{ saving ? '⏳ Saving...' : '💾 Save Invoice' }}
          </button>
          <button class="btn-print" (click)="printBill()" [disabled]="!lastInvoice" title="Print">🖨</button>
          <button class="btn-clear" (click)="clearBill()">🗑</button>
        </div>

        <!-- Success -->
        <div class="success-box" *ngIf="lastInvoice">
          <div class="sb-title">✅ Invoice Saved!</div>
          <div class="sb-detail">{{ lastInvoice.invoiceNo }} &bull; Total: {{ cur }}{{ lastInvoice.total | number:'1.0-0' }}</div>
          <div class="sb-balance" *ngIf="lastInvoice.balance > 0">Balance due: {{ cur }}{{ lastInvoice.balance | number:'1.0-0' }}</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Hidden print area -->
<div id="print-area" style="display:none">
  <div *ngIf="lastInvoice" style="font-family:sans-serif;max-width:400px;margin:0 auto;padding:20px">
    <div style="text-align:center;border-bottom:2px solid #0a1628;padding-bottom:12px;margin-bottom:12px">
      <h2 style="color:#0a1628;margin:0;font-size:20px">Pixous Hardware</h2>
      <p style="font-size:11px;color:#64748b;margin:4px 0">{{ storeAddress }}</p>
      <p style="font-size:11px;color:#64748b;margin:0">GST: {{ gstNo }}</p>
    </div>
    <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:12px">
      <div><strong>Invoice:</strong> {{ lastInvoice.invoiceNo }}<br><strong>Date:</strong> {{ invoiceDate }}</div>
      <div><strong>Customer:</strong> {{ customerName }}</div>
    </div>
    <table style="width:100%;border-collapse:collapse;font-size:11px;margin-bottom:12px">
      <thead>
        <tr style="background:#0a1628;color:#c9a84c">
          <th style="padding:6px;text-align:left">Item</th>
          <th style="padding:6px;text-align:center">Qty</th>
          <th style="padding:6px;text-align:right">Price</th>
          <th style="padding:6px;text-align:right">Tax</th>
          <th style="padding:6px;text-align:right">Total</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let item of cartItems" style="border-bottom:1px solid #f1f5f9">
          <td style="padding:5px">{{ item.productName }}</td>
          <td style="padding:5px;text-align:center">{{ item.qty }} {{ item.unit }}</td>
          <td style="padding:5px;text-align:right">{{ cur }}{{ item.price }}</td>
          <td style="padding:5px;text-align:right">{{ cur }}{{ item.taxAmount | number:'1.2-2' }}</td>
          <td style="padding:5px;text-align:right">{{ cur }}{{ item.lineTotal | number:'1.2-2' }}</td>
        </tr>
      </tbody>
    </table>
    <div style="text-align:right;font-size:12px;border-top:1px solid #e2e8f0;padding-top:8px">
      <p>Subtotal: {{ cur }}{{ subtotal | number:'1.2-2' }}</p>
      <p>Discount: −{{ cur }}{{ discountAmount | number:'1.2-2' }}</p>
      <p>GST: {{ cur }}{{ taxTotal | number:'1.2-2' }}</p>
      <p style="font-size:15px;font-weight:700;color:#0a1628">TOTAL: {{ cur }}{{ grandTotal | number:'1.2-2' }}</p>
      <p>Paid: {{ cur }}{{ amountPaid | number:'1.2-2' }}</p>
      <p style="color:#ef4444">Balance: {{ cur }}{{ (grandTotal - amountPaid) | number:'1.2-2' }}</p>
    </div>
    <div style="text-align:center;margin-top:16px;font-size:11px;color:#64748b;border-top:1px solid #e2e8f0;padding-top:8px">
      Thank you for shopping at Pixous Hardware!
    </div>
  </div>
</div>
  `,
  styles: [`
    .billing-screen {
      display: grid;
      grid-template-columns: 1fr 320px;
      gap: 16px;
      align-items: start;
    }
    .billing-left { display: flex; flex-direction: column; gap: 14px; }

    /* Panel */
    .panel {
      background: var(--white);
      border-radius: var(--radius-lg);
      border: 1px solid var(--gray-border);
      overflow: hidden;
      box-shadow: var(--shadow-sm);
    }
    .panel-header {
      display: flex;
      align-items: center;
      gap: 8px;
      background: var(--navy);
      color: var(--gold-light);
      padding: 10px 16px;
      font-size: 13px;
      font-weight: 700;
      letter-spacing: 0.3px;
    }
    .ph-icon { font-size: 15px; }
    .item-count {
      margin-left: auto;
      background: var(--gold);
      color: var(--navy);
      font-size: 10px;
      font-weight: 800;
      padding: 2px 8px;
      border-radius: 20px;
    }
    .panel-body { padding: 14px; }

    /* Form controls */
    .fc {
      width: 100%;
      padding: 9px 12px;
      border: 1px solid var(--gray-border);
      border-radius: var(--radius-md);
      font-size: 13px;
      outline: none;
      box-sizing: border-box;
      color: var(--text-dark);
      transition: border-color 0.15s, box-shadow 0.15s;
    }
    .fc:focus { border-color: var(--gold); box-shadow: 0 0 0 3px rgba(201,168,76,0.15); }

    .input-row { display: flex; gap: 8px; }
    .icon-btn {
      width: 38px; height: 38px; flex-shrink: 0;
      border: 1px solid var(--gray-border);
      border-radius: var(--radius-md);
      background: var(--gray-soft);
      cursor: pointer;
      font-size: 20px;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.15s;
    }
    .icon-btn:hover { background: var(--gold); color: var(--navy); border-color: var(--gold); }

    .cust-info { display: flex; gap: 12px; margin-top: 8px; font-size: 12px; align-items: center; }
    .ci-item { color: var(--text-muted); }
    .ci-due { background: #fee2e2; color: #991b1b; padding: 3px 8px; border-radius: 20px; font-weight: 700; font-size: 11px; }

    .quick-add { display: flex; flex-direction: column; gap: 8px; margin-top: 10px; }
    .btn-save-cust {
      background: var(--navy); color: var(--gold);
      border: none; padding: 8px; border-radius: var(--radius-md);
      font-weight: 700; font-size: 13px; cursor: pointer;
    }

    .search-fc { font-size: 14px; }
    .prod-dropdown {
      margin-top: 8px;
      border: 1px solid var(--gray-border);
      border-radius: var(--radius-md);
      overflow: hidden;
      max-height: 260px;
      overflow-y: auto;
    }
    .prod-opt {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 14px;
      cursor: pointer;
      border-bottom: 1px solid #f8fafc;
      transition: background 0.1s;
    }
    .prod-opt:hover { background: var(--gold-soft); }
    .po-name { font-size: 13px; font-weight: 600; color: var(--navy); }
    .po-meta { font-size: 10px; color: var(--text-muted); margin-top: 2px; }
    .po-price { font-size: 14px; font-weight: 800; color: var(--gold-dark); }

    /* Cart */
    .empty-cart {
      display: flex; flex-direction: column; align-items: center; gap: 8px;
      padding: 36px; color: var(--text-muted); font-size: 13px;
    }
    .ec-icon { font-size: 32px; }
    .cart-wrap { overflow-x: auto; }
    .cart-tbl { width: 100%; border-collapse: collapse; font-size: 12px; }
    .cart-tbl th {
      background: var(--navy-soft);
      padding: 9px 10px;
      text-align: left;
      font-size: 10px;
      text-transform: uppercase;
      color: var(--navy);
      border-bottom: 1px solid var(--gray-border);
    }
    .cart-tbl td { padding: 9px 10px; border-bottom: 1px solid #f8fafc; vertical-align: middle; }
    .cart-tbl tr:hover td { background: var(--gold-soft); }
    .ci-name { font-weight: 600; color: var(--navy); }
    .ci-sku  { font-size: 10px; color: var(--text-muted); }
    .tc { text-align: center !important; }
    .tr { text-align: right !important; }
    .fw { font-weight: 700; }
    .muted { color: var(--text-muted); }
    .num-input {
      width: 52px; padding: 5px 6px;
      border: 1px solid var(--gray-border);
      border-radius: 6px; font-size: 12px;
      text-align: center;
    }
    .num-input.wide { width: 72px; }
    .rm-btn {
      background: none; border: none;
      color: var(--danger); cursor: pointer;
      font-size: 13px; padding: 4px 8px;
      border-radius: 6px; transition: background 0.1s;
    }
    .rm-btn:hover { background: #fee2e2; }

    /* Summary card */
    .billing-right { position: sticky; top: 0; }
    .summary-card {
      background: var(--white);
      border-radius: var(--radius-lg);
      border: 1px solid var(--gray-border);
      overflow: hidden;
      box-shadow: var(--shadow-md);
    }
    .sc-header {
      background: linear-gradient(135deg, var(--navy) 0%, var(--navy-mid) 100%);
      color: var(--gold);
      padding: 14px 18px;
      font-size: 14px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 8px;
      letter-spacing: 0.3px;
    }
    .sc-logo { font-size: 12px; }

    .sum-rows { padding: 14px 18px 0; border-bottom: 1px solid var(--gray-border); margin-bottom: 4px; }
    .sum-row {
      display: flex; justify-content: space-between;
      padding: 6px 0; font-size: 13px;
      color: var(--text-mid);
      border-bottom: 1px dashed #f1f5f9;
    }
    .discount-row { color: var(--text-muted); }
    .text-red { color: var(--danger); }
    .total-row {
      font-size: 16px; font-weight: 800; color: var(--navy);
      border-top: 2px solid var(--navy);
      border-bottom: none;
      margin-top: 4px; padding-top: 8px; padding-bottom: 12px;
    }

    .sc-body { padding: 0 18px 16px; }
    .field-block { padding-top: 12px; }
    .field-block label {
      display: block; font-size: 10px; font-weight: 700;
      text-transform: uppercase; letter-spacing: 0.5px;
      color: var(--text-muted); margin-bottom: 5px;
    }

    .mode-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
    .mode-btn {
      display: flex; align-items: center; justify-content: center; gap: 5px;
      padding: 7px 6px;
      border: 1px solid var(--gray-border);
      border-radius: var(--radius-md);
      background: var(--gray-soft);
      cursor: pointer; font-size: 11px; font-weight: 600;
      transition: all 0.15s; color: var(--text-mid);
    }
    .mode-btn.active {
      background: var(--navy); color: var(--gold);
      border-color: var(--navy);
    }
    .mode-btn:hover:not(.active) { border-color: var(--gold); color: var(--gold-dark); }

    .amount-input { font-size: 16px !important; font-weight: 700 !important; }

    .balance-row {
      display: flex; justify-content: space-between; align-items: center;
      margin: 12px 0; padding: 12px 14px;
      background: var(--navy-soft); border-radius: var(--radius-md);
      font-weight: 700; font-size: 14px; color: var(--navy);
    }
    .balance-row.has-due { background: #fff7ed; color: #9a3412; }
    .bal-val { font-size: 18px; }

    .action-row { display: flex; gap: 8px; padding-top: 14px; }
    .btn-save {
      flex: 1;
      background: linear-gradient(135deg, var(--gold) 0%, var(--gold-dark) 100%);
      color: var(--navy); border: none; padding: 12px;
      border-radius: var(--radius-md); font-size: 13px; font-weight: 800;
      cursor: pointer; transition: all 0.15s;
      box-shadow: 0 2px 8px rgba(201,168,76,0.3);
    }
    .btn-save:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(201,168,76,0.4); }
    .btn-save:disabled { opacity: 0.5; cursor: not-allowed; }
    .btn-print {
      background: var(--navy); color: var(--white);
      border: none; padding: 12px 14px;
      border-radius: var(--radius-md); cursor: pointer; font-size: 14px;
    }
    .btn-clear {
      background: var(--gray-soft); border: 1px solid var(--gray-border);
      padding: 12px 14px; border-radius: var(--radius-md);
      cursor: pointer; font-size: 14px;
    }

    .success-box {
      margin-top: 12px; padding: 12px 14px;
      background: #f0fdf4; border: 1px solid #86efac;
      border-radius: var(--radius-md);
    }
    .sb-title { font-size: 13px; font-weight: 700; color: #166534; }
    .sb-detail { font-size: 12px; color: #166534; margin-top: 4px; }
    .sb-balance { font-size: 12px; color: var(--danger); margin-top: 2px; }

    /* Responsive */
    @media (max-width: 900px) {
      .billing-screen { grid-template-columns: 1fr; }
      .billing-right { position: static; }
    }
    @media (max-width: 480px) {
      .cart-tbl th:nth-child(5), .cart-tbl td:nth-child(5) { display: none; }
      .mode-grid { grid-template-columns: repeat(4, 1fr); }
      .mode-btn span:first-child { font-size: 14px; }
      .mode-btn span:last-child { display: none; }
    }
  `]
})
export class BillingComponent implements OnInit {
  cur = environment.currency;
  storeName = environment.storeName;
  storeAddress = environment.storeAddress;
  gstNo = environment.gstNo;

  customers: any[] = [];
  products: any[] = [];
  filteredProducts: any[] = [];
  cartItems: any[] = [];

  selectedCustomerId = '';
  selectedCustomer: any = null;
  customerName = 'Walk-in Customer';
  productSearch = '';
  billDiscount = 0;
  paymentMode = 'cash';
  amountPaid = 0;
  invoiceDate = new Date().toISOString().substring(0, 10);
  notes = '';
  saving = false;
  showNewCustomer = false;
  lastInvoice: any = null;
  newCust = { name: '', phone: '', address: '' };

  paymentModes = [
    { value: 'cash',   label: 'Cash',   icon: '💵' },
    { value: 'upi',    label: 'UPI',    icon: '📱' },
    { value: 'card',   label: 'Card',   icon: '💳' },
    { value: 'credit', label: 'Credit', icon: '📋' },
  ];

  get subtotal() { return this.cartItems.reduce((s, i) => s + (i.qty * i.price * (1 - i.discount / 100)), 0); }
  get discountAmount() { return this.subtotal * this.billDiscount / 100; }
  get taxTotal() { return this.cartItems.reduce((s, i) => s + i.taxAmount, 0); }
  get grandTotal() { return this.subtotal - this.discountAmount + this.taxTotal; }

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.api.getCustomers().subscribe(c => this.customers = c);
    this.api.getProducts().subscribe(p => this.products = p);
  }

  onCustomerChange() {
    this.selectedCustomer = this.customers.find(c => c.id === this.selectedCustomerId) || null;
    this.customerName = this.selectedCustomer?.name || 'Walk-in Customer';
  }

  filterProducts() {
    const q = this.productSearch.toLowerCase();
    this.filteredProducts = q ? this.products.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.sku.toLowerCase().includes(q) ||
      (p.barcode && p.barcode.includes(q))
    ) : [];
  }

  addToCart(product: any) {
    const existing = this.cartItems.find(i => i.productId === product.id);
    if (existing) { existing.qty++; this.recalcItem(existing); }
    else {
      const item = { productId: product.id, sku: product.sku, productName: product.name,
        qty: 1, unit: product.unit, price: Number(product.price),
        discount: 0, taxRate: Number(product.taxRate), taxAmount: 0, lineTotal: 0 };
      this.recalcItem(item);
      this.cartItems.push(item);
    }
    this.productSearch = '';
    this.filteredProducts = [];
  }

  recalcItem(item: any) {
    const base = item.qty * item.price * (1 - item.discount / 100);
    item.taxAmount = base * item.taxRate / 100;
    item.lineTotal = base + item.taxAmount;
  }

  recalcTotals() {}
  removeItem(i: number) { this.cartItems.splice(i, 1); }

  addCustomer() {
    if (!this.newCust.name) return;
    this.api.createCustomer(this.newCust).subscribe(r => {
      this.api.getCustomers().subscribe(c => {
        this.customers = c;
        this.selectedCustomerId = r.id;
        this.onCustomerChange();
        this.showNewCustomer = false;
        this.newCust = { name: '', phone: '', address: '' };
      });
    });
  }

  saveBill() {
    if (!this.cartItems.length) return;
    this.saving = true;
    const paid = this.paymentMode === 'credit' ? (this.amountPaid || 0) : (this.amountPaid || this.grandTotal);
    this.api.createInvoice({
      date: this.invoiceDate,
      customerId: this.selectedCustomerId || 'C003',
      customerName: this.customerName,
      items: this.cartItems,
      subtotal: this.subtotal,
      discountAmount: this.discountAmount,
      taxAmount: this.taxTotal,
      total: this.grandTotal,
      paidAmount: paid,
      paymentMode: this.paymentMode,
      notes: this.notes,
      createdBy: 'admin',
    }).subscribe({
      next: r => { this.lastInvoice = r; this.saving = false; },
      error: () => { this.saving = false; alert('Error saving. Check API URL in environment.ts'); }
    });
  }

  printBill() {
    if (!this.lastInvoice) return;
    const w = window.open('', '_blank');
    const el = document.getElementById('print-area');
    if (w && el) { w.document.write('<html><body>' + el.innerHTML + '</body></html>'); w.document.close(); w.print(); }
  }

  clearBill() {
    this.cartItems = []; this.billDiscount = 0; this.amountPaid = 0;
    this.paymentMode = 'cash'; this.notes = ''; this.lastInvoice = null;
    this.selectedCustomerId = ''; this.selectedCustomer = null;
    this.customerName = 'Walk-in Customer';
  }
}
