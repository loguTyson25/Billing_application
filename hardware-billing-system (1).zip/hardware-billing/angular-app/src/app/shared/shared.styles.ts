// src/app/shared/shared.styles.ts
// Add these shared styles to each component's styles[] array

export const SHARED_TABLE_STYLES = `
  .page { display: flex; flex-direction: column; gap: 16px; }

  .toolbar {
    display: flex; gap: 12px; align-items: center;
    justify-content: space-between; flex-wrap: wrap;
  }
  .toolbar-right { display: flex; gap: 8px; flex-wrap: wrap; }

  .search-input {
    flex: 1; min-width: 160px; max-width: 300px;
    padding: 9px 14px;
    border: 1px solid var(--gray-border);
    border-radius: var(--radius-md);
    font-size: 13px;
  }
  .search-input:focus { outline: none; border-color: var(--gold); }

  .filter-select {
    padding: 9px 12px;
    border: 1px solid var(--gray-border);
    border-radius: var(--radius-md);
    font-size: 13px;
  }

  .btn-primary {
    background: linear-gradient(135deg, var(--gold) 0%, var(--gold-dark) 100%);
    color: var(--navy);
    border: none; padding: 9px 18px;
    border-radius: var(--radius-md);
    font-size: 13px; font-weight: 700; cursor: pointer;
    white-space: nowrap;
  }
  .btn-secondary {
    background: var(--gray-soft);
    border: 1px solid var(--gray-border);
    padding: 9px 18px; border-radius: var(--radius-md);
    font-size: 13px; cursor: pointer;
  }

  .table-card {
    background: var(--white);
    border-radius: var(--radius-lg);
    border: 1px solid var(--gray-border);
    overflow: auto;
    box-shadow: var(--shadow-sm);
  }
  .main-table { width: 100%; border-collapse: collapse; font-size: 13px; }
  .main-table th {
    background: var(--navy);
    color: var(--gold-light);
    padding: 10px 14px; text-align: left;
    font-size: 10px; text-transform: uppercase;
    letter-spacing: 0.5px; white-space: nowrap;
    border-bottom: 2px solid var(--gold-dark);
  }
  .main-table td {
    padding: 11px 14px;
    border-bottom: 1px solid #f8fafc;
    color: var(--text-mid);
  }
  .main-table tr:last-child td { border-bottom: none; }
  .main-table tr:hover td { background: var(--gold-soft); }

  .mono { font-family: monospace; color: var(--navy-mid); font-weight: 700; font-size: 12px; }

  .badge { font-size: 10px; padding: 3px 8px; border-radius: 20px; font-weight: 700; text-transform: uppercase; }
  .b-paid    { background: #dcfce7; color: #166534; }
  .b-partial { background: #fef9c3; color: #854d0e; }
  .b-unpaid  { background: #fee2e2; color: #991b1b; }
  .b-green   { background: #dcfce7; color: #166534; }
  .b-amber   { background: #fef9c3; color: #854d0e; }
  .b-red     { background: #fee2e2; color: #991b1b; }

  .empty-state { text-align: center; padding: 48px; color: var(--text-muted); font-size: 13px; }

  /* Modal */
  .modal-overlay {
    position: fixed; inset: 0;
    background: rgba(10,22,40,0.6);
    display: flex; align-items: center; justify-content: center;
    z-index: 1000;
    backdrop-filter: blur(3px);
    padding: 16px;
  }
  .modal {
    background: var(--white);
    border-radius: var(--radius-lg);
    width: 620px; max-width: 100%;
    max-height: 90vh;
    display: flex; flex-direction: column;
    box-shadow: var(--shadow-md);
  }
  .modal-header {
    padding: 16px 20px;
    background: var(--navy);
    color: var(--gold);
    font-size: 15px; font-weight: 700;
    display: flex; justify-content: space-between; align-items: center;
    border-radius: var(--radius-lg) var(--radius-lg) 0 0;
  }
  .modal-close {
    background: none; border: none; cursor: pointer;
    font-size: 20px; color: var(--gold-light); line-height: 1;
  }
  .modal-body { padding: 20px; overflow-y: auto; flex: 1; }
  .modal-footer {
    padding: 14px 20px;
    border-top: 1px solid var(--gray-border);
    display: flex; gap: 10px; justify-content: flex-end;
  }

  .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
  .field { display: flex; flex-direction: column; gap: 5px; }
  .field.full { grid-column: 1 / -1; }
  .field label {
    font-size: 10px; font-weight: 700;
    text-transform: uppercase; letter-spacing: 0.5px;
    color: var(--text-muted);
  }
  .fc {
    padding: 9px 12px;
    border: 1px solid var(--gray-border);
    border-radius: var(--radius-md);
    font-size: 13px; width: 100%; box-sizing: border-box;
    color: var(--text-dark);
  }
  .fc:focus { outline: none; border-color: var(--gold); box-shadow: 0 0 0 3px rgba(201,168,76,0.15); }

  @media (max-width: 768px) {
    .form-grid { grid-template-columns: 1fr; }
    .toolbar { flex-direction: column; align-items: stretch; }
    .toolbar-right { justify-content: flex-end; }
    .search-input { max-width: 100%; }
    .modal { max-height: 100vh; }
  }
`;
