// src/app/shared/layout/layout.component.ts
import { Component, OnInit, HostListener } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { environment } from '../../../environments/environment';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-layout',
  template: `
<!-- Mobile header -->
<header class="mobile-header">
  <button class="hamburger" (click)="toggleSidebar()" [attr.aria-label]="sidebarOpen ? 'Close menu' : 'Open menu'">
    <span></span><span></span><span></span>
  </button>
  <div class="mobile-brand">
    <span class="brand-gem">◆</span>
    <span class="brand-text">Pixous</span>
  </div>
  <a routerLink="/billing" class="mobile-bill-btn">+ Bill</a>
</header>

<!-- Sidebar overlay (mobile) -->
<div class="sidebar-overlay" [class.visible]="sidebarOpen" (click)="closeSidebar()"></div>

<div class="app-shell">
  <!-- Sidebar -->
  <aside class="sidebar" [class.open]="sidebarOpen" [class.collapsed]="sidebarCollapsed">

    <!-- Brand -->
    <div class="brand">
      <div class="brand-logo">
        <span class="brand-gem">◆</span>
      </div>
      <div class="brand-info" *ngIf="!sidebarCollapsed">
        <div class="brand-name">Pixous</div>
        <div class="brand-sub">Hardware</div>
      </div>
      <button class="collapse-toggle" (click)="sidebarCollapsed = !sidebarCollapsed" *ngIf="!isMobile">
        <span>{{ sidebarCollapsed ? '›' : '‹' }}</span>
      </button>
    </div>

    <!-- Nav -->
    <nav class="nav-links" role="navigation">
      <a *ngFor="let item of navItems"
         [routerLink]="item.path"
         routerLinkActive="active"
         class="nav-item"
         [title]="item.label"
         (click)="closeSidebar()">
        <span class="nav-icon" aria-hidden="true">{{ item.icon }}</span>
        <span class="nav-label">{{ item.label }}</span>
        <span class="nav-badge" *ngIf="item.badge">{{ item.badge }}</span>
      </a>
    </nav>

    <!-- Footer -->
    <div class="sidebar-bottom">
      <div class="store-info" *ngIf="!sidebarCollapsed">
        <div class="si-name">{{ storeName }}</div>
        <div class="si-gst">GST: {{ gstNo }}</div>
      </div>
    </div>
  </aside>

  <!-- Main -->
  <main class="main-content">
    <header class="topbar">
      <div class="topbar-left">
        <h1 class="page-title">{{ currentPageTitle }}</h1>
      </div>
      <div class="topbar-right">
        <span class="gst-chip">{{ gstNo }}</span>
        <a routerLink="/billing" class="btn-new-bill">
          <span>+</span> New Bill
        </a>
      </div>
    </header>

    <div class="content-area">
      <router-outlet></router-outlet>
    </div>
  </main>
</div>
  `,
  styles: [`
    /* ── Mobile Header ─────────────────────────────────────── */
    .mobile-header {
      display: none;
      position: fixed;
      top: 0; left: 0; right: 0;
      height: 56px;
      background: var(--navy);
      z-index: 200;
      align-items: center;
      justify-content: space-between;
      padding: 0 16px;
      border-bottom: 2px solid var(--gold);
    }
    .hamburger {
      display: flex; flex-direction: column; gap: 5px;
      background: none; border: none; cursor: pointer; padding: 4px;
    }
    .hamburger span {
      display: block; width: 22px; height: 2px;
      background: var(--gold); border-radius: 2px;
      transition: all 0.2s;
    }
    .mobile-brand { display: flex; align-items: center; gap: 8px; }
    .mobile-bill-btn {
      background: var(--gold); color: var(--navy);
      border: none; padding: 6px 12px; border-radius: 6px;
      font-size: 12px; font-weight: 700; cursor: pointer;
      text-decoration: none;
    }

    /* ── Overlay (mobile) ──────────────────────────────────── */
    .sidebar-overlay {
      display: none;
      position: fixed; inset: 0;
      background: rgba(10,22,40,0.6);
      z-index: 149;
      backdrop-filter: blur(2px);
    }
    .sidebar-overlay.visible { display: block; }

    /* ── App Shell ─────────────────────────────────────────── */
    .app-shell {
      display: flex;
      height: 100vh;
      overflow: hidden;
    }

    /* ── Sidebar ───────────────────────────────────────────── */
    .sidebar {
      width: 230px;
      background: var(--navy);
      display: flex;
      flex-direction: column;
      flex-shrink: 0;
      transition: width 0.3s ease;
      overflow: hidden;
      border-right: 1px solid var(--navy-light);
      z-index: 150;
    }
    .sidebar.collapsed { width: 64px; }

    /* Brand */
    .brand {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 20px 16px;
      border-bottom: 1px solid rgba(201,168,76,0.2);
      background: linear-gradient(135deg, var(--navy) 0%, var(--navy-mid) 100%);
      min-height: 72px;
    }
    .brand-logo {
      width: 38px; height: 38px;
      background: linear-gradient(135deg, var(--gold) 0%, var(--gold-dark) 100%);
      border-radius: 10px;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
      box-shadow: 0 2px 8px rgba(201,168,76,0.4);
    }
    .brand-gem { color: var(--navy); font-size: 16px; font-weight: 700; }
    .brand-info { overflow: hidden; }
    .brand-name {
      font-family: 'Orbitron', sans-serif;
      font-size: 14px; font-weight: 700;
      color: var(--gold); letter-spacing: 1px;
      white-space: nowrap;
    }
    .brand-sub {
      font-size: 10px; color: var(--gray-light);
      letter-spacing: 3px; text-transform: uppercase;
      white-space: nowrap;
    }
    .collapse-toggle {
      margin-left: auto;
      background: rgba(255,255,255,0.05);
      border: 1px solid rgba(255,255,255,0.1);
      color: var(--gray-light);
      width: 24px; height: 24px;
      border-radius: 6px; cursor: pointer;
      font-size: 14px; flex-shrink: 0;
      display: flex; align-items: center; justify-content: center;
      transition: all 0.15s;
    }
    .collapse-toggle:hover { background: rgba(201,168,76,0.15); color: var(--gold); }

    /* Nav */
    .nav-links {
      flex: 1;
      padding: 12px 8px;
      display: flex; flex-direction: column;
      gap: 2px;
      overflow-y: auto;
    }
    .nav-item {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 10px 12px;
      border-radius: var(--radius-md);
      color: var(--gray-light);
      text-decoration: none;
      font-size: 13px; font-weight: 500;
      transition: all 0.15s;
      white-space: nowrap;
      position: relative;
    }
    .nav-item:hover {
      background: rgba(201,168,76,0.08);
      color: var(--gold-light);
    }
    .nav-item.active {
      background: linear-gradient(135deg, rgba(201,168,76,0.2) 0%, rgba(201,168,76,0.08) 100%);
      color: var(--gold);
      border-left: 3px solid var(--gold);
      padding-left: 9px;
    }
    .nav-icon { font-size: 16px; flex-shrink: 0; width: 20px; text-align: center; }
    .nav-label { flex: 1; }
    .nav-badge {
      background: var(--gold);
      color: var(--navy);
      font-size: 9px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 10px;
    }

    /* Sidebar bottom */
    .sidebar-bottom {
      padding: 12px 16px;
      border-top: 1px solid rgba(201,168,76,0.15);
    }
    .si-name { font-size: 11px; font-weight: 600; color: var(--gold-light); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .si-gst  { font-size: 10px; color: var(--gray-light); margin-top: 2px; white-space: nowrap; overflow: hidden; }

    /* ── Main content ──────────────────────────────────────── */
    .main-content {
      flex: 1;
      display: flex;
      flex-direction: column;
      min-width: 0;
      overflow: hidden;
    }

    /* Topbar */
    .topbar {
      background: var(--white);
      border-bottom: 1px solid var(--gray-border);
      padding: 0 24px;
      height: 60px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-shrink: 0;
      box-shadow: var(--shadow-sm);
    }
    .page-title {
      font-size: 18px;
      font-weight: 700;
      color: var(--navy);
      margin: 0;
      letter-spacing: -0.3px;
    }
    .topbar-right { display: flex; align-items: center; gap: 12px; }
    .gst-chip {
      font-size: 11px;
      background: var(--navy-soft);
      color: var(--navy-mid);
      border: 1px solid rgba(10,22,40,0.15);
      padding: 4px 10px;
      border-radius: 20px;
      font-weight: 600;
      letter-spacing: 0.3px;
    }
    .btn-new-bill {
      background: linear-gradient(135deg, var(--gold) 0%, var(--gold-dark) 100%);
      color: var(--navy);
      border: none;
      padding: 9px 18px;
      border-radius: var(--radius-md);
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      text-decoration: none;
      display: flex; align-items: center; gap: 4px;
      box-shadow: 0 2px 8px rgba(201,168,76,0.35);
      transition: all 0.15s;
      white-space: nowrap;
    }
    .btn-new-bill:hover {
      background: linear-gradient(135deg, var(--gold-light) 0%, var(--gold) 100%);
      box-shadow: 0 4px 12px rgba(201,168,76,0.45);
      transform: translateY(-1px);
    }

    /* Content area */
    .content-area {
      flex: 1;
      overflow-y: auto;
      padding: 24px;
      background: var(--gray-soft);
    }

    /* ── Responsive ────────────────────────────────────────── */

    /* Tablet (≤ 1024px) */
    @media (max-width: 1024px) {
      .sidebar { width: 64px; }
      .brand-info, .nav-label, .sidebar-bottom, .nav-badge, .collapse-toggle { display: none !important; }
      .brand { justify-content: center; padding: 16px 8px; }
      .nav-item { justify-content: center; padding: 10px; }
      .nav-item.active { border-left: none; padding-left: 10px; border-bottom: 2px solid var(--gold); }
      .topbar { padding: 0 16px; }
      .content-area { padding: 16px; }
    }

    /* Mobile (≤ 768px) */
    @media (max-width: 768px) {
      .mobile-header { display: flex; }
      .app-shell { padding-top: 56px; }
      .sidebar {
        position: fixed;
        top: 56px; left: 0; bottom: 0;
        width: 260px !important;
        transform: translateX(-100%);
        transition: transform 0.3s ease;
        z-index: 150;
      }
      .sidebar.open { transform: translateX(0); }
      .brand-info, .nav-label, .sidebar-bottom, .nav-badge { display: flex !important; }
      .brand-info { display: block !important; }
      .collapse-toggle { display: none !important; }
      .nav-item { justify-content: flex-start !important; padding: 10px 12px !important; }
      .nav-item.active { border-left: 3px solid var(--gold) !important; border-bottom: none !important; padding-left: 9px !important; }
      .topbar { display: none; }
      .content-area { padding: 12px; }
      .main-content { overflow-y: auto; }
      .gst-chip { display: none; }
    }

    /* Small mobile (≤ 480px) */
    @media (max-width: 480px) {
      .content-area { padding: 10px; }
    }
  `]
})
export class LayoutComponent implements OnInit {
  storeName = environment.storeName;
  gstNo = environment.gstNo;
  sidebarCollapsed = false;
  sidebarOpen = false;
  isMobile = false;
  currentPageTitle = 'Dashboard';

  navItems = [
    { path: '/dashboard', label: 'Dashboard',  icon: '📊' },
    { path: '/billing',   label: 'New Bill',   icon: '🧾' },
    { path: '/invoices',  label: 'Invoices',   icon: '📄' },
    { path: '/products',  label: 'Products',   icon: '📦' },
    { path: '/customers', label: 'Customers',  icon: '👥' },
    { path: '/payments',  label: 'Payments',   icon: '💳' },
    { path: '/returns',   label: 'Returns',    icon: '↩️' },
    { path: '/suppliers', label: 'Suppliers',  icon: '🏭' },
    { path: '/reports',   label: 'Reports',    icon: '📈' },
  ];

  constructor(private router: Router) {}

  ngOnInit() {
    this.checkMobile();
    this.router.events
      .pipe(filter(e => e instanceof NavigationEnd))
      .subscribe(() => {
        const seg = this.router.url.split('/')[1];
        const item = this.navItems.find(n => n.path.includes(seg));
        this.currentPageTitle = item ? item.label : 'Pixous Hardware';
        this.closeSidebar();
      });
  }

  @HostListener('window:resize')
  checkMobile() {
    this.isMobile = window.innerWidth <= 768;
    if (!this.isMobile) this.sidebarOpen = false;
  }

  toggleSidebar() { this.sidebarOpen = !this.sidebarOpen; }
  closeSidebar()  { this.sidebarOpen = false; }
}
