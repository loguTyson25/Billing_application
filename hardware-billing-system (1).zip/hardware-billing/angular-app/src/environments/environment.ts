// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'https://script.google.com/macros/s/YOUR_SCRIPT_ID/exec',
  appName: 'Pixous Hardware',
  currency: '₹',
  gstNo: 'YOUR_GST_NUMBER',
  storeName: 'Pixous Hardware',
  storeAddress: 'No.12, Anna Nagar, Chennai - 600040',
  storePhone: '+91 98765 43210',
};
